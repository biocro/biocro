
extern double TempToDdryA(double Temp);

extern double TempToLHV(double Temp);

extern double TempToSFS(double Temp);


extern double TempToSWVC(double Temp);
